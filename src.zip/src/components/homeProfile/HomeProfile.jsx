import "./HomeProfile.css";

function HomeProfile() {
  return <div className="home-profile"></div>;
}

export default HomeProfile;
