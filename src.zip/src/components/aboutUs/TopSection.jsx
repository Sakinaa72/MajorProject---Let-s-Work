import React from "react";

function TopSection() {
  return (
    <div>
      <div>
        <img className="aboutusimg" src="./images/our-team-banner.jpg" alt="" />
        <div className="centered"></div>
      </div>
    </div>
  );
}

export default TopSection;
