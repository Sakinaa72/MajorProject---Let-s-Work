import React from "react";
import OrgNavBar from "./OrgNavBar";

function ReviewApplication() {
  return (
    <div>
      <OrgNavBar />
    </div>
  );
}

export default ReviewApplication;
