import React from "react";
import OrgNavBar from "./OrgNavBar";

function OrgProfile() {
  return (
    <div>
      <OrgNavBar />
    </div>
  );
}

export default OrgProfile;
